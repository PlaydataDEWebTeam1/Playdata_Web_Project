package com.work.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.work.dto.Board;
import com.work.dto.Criteria;
import com.work.dto.PageMaker;
import com.work.dto.Reply;
import com.work.dto.SearchCriteria;
import com.work.service.BoardService;
import com.work.service.ReplyService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class BoardController {
	
	@Autowired
	public BoardService boardService;
	
	@Autowired
	public ReplyService replyService;
	
	
	/** 게시판 글 작성 페이지 */
	@RequestMapping("/addDoc")
	public String addDoc() {
		return "board/addDoc";
	}
	
	/** 게시판 글 추가 */
	@RequestMapping("/insert")
	public String insert(Board dto, Model model) {
		int result = boardService.insert(dto);
		if (result == 1) {
			model.addAttribute("message", "[레시피를 등록하였습니다.]");
			return "redirect:/recipeList";
		} else {
			model.addAttribute("message", "[레시피 등록에 실패하셨습니다. 정보를확인해주세요.] ");
			return "board/addDoc";
		}
	}

	/** 게시판 글 목록 조회 */
	@RequestMapping("/list")
	public String list(@ModelAttribute("scri") SearchCriteria scri, Model model) {
		model.addAttribute("list", boardService.list(scri));
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(scri);
		pageMaker.setTotalCount(boardService.listCount(scri));
		
		model.addAttribute("pageMaker", pageMaker);
		
		return "board/list";
	}
	
	/** 게시판 글 목록 조회 */
	@RequestMapping("/listImage")
	public String listImage(@ModelAttribute("scri") SearchCriteria scri, Model model) {
		model.addAttribute("list", boardService.list(scri));
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(scri);
		pageMaker.setTotalCount(boardService.listCount(scri));
		
		model.addAttribute("pageMaker", pageMaker);
		
		return "board/listImage";
	}
	
	/** 게시판 글 목록 조회 */
	@RequestMapping("/recipeList")
	public String recipeList(@ModelAttribute("scri") SearchCriteria scri, Model model) {
		model.addAttribute("list", boardService.list(scri));
		
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(scri);
		pageMaker.setTotalCount(boardService.listCount(scri));
		
		model.addAttribute("pageMaker", pageMaker);
		
		return "/recipeList";
	}
	
	
	/** 게시판 글 조회 */
	@RequestMapping("/readView")
	public String read(Board dto, @ModelAttribute("scri") SearchCriteria scri, Model model) {
		model.addAttribute("read", boardService.read(dto.getBno()));
		model.addAttribute("scri", scri);
		
		List<Reply> replyList = replyService.readReply(dto.getBno());
		model.addAttribute("replyList", replyList);
		return "board/readView";
	}

	/** 게시판 글 수정 뷰 */
	@RequestMapping("/updateView")
	public String updateView(Board dto, Model model) {
		model.addAttribute("update", boardService.read(dto.getBno()));
		
		return "board/updateView";
	}
	
	/** 게시판 글 수정 */
	@RequestMapping("/update")
	public String update(Board dto) {
		boardService.update(dto);
		
		return "redirect:/recipeList";
	}
	
	/** 게시판 글 삭제 */
	@RequestMapping("/delete")
	public String delete(Board dto) {
		boardService.delete(dto.getBno());
		
		return "redirect:/recipeList";
	}
	
	/** 댓글 작성 */
	
	@RequestMapping("/replyWrite")
	public String replyWrite(Reply dto, SearchCriteria scri, RedirectAttributes rttr) {
		
		replyService.writeReply(dto);
		
		rttr.addAttribute("bno", dto.getBno());
		rttr.addAttribute("page", scri.getPage());
		rttr.addAttribute("perPageNum", scri.getPerPageNum());
		rttr.addAttribute("searchType", scri.getSearchType());
		rttr.addAttribute("keyword", scri.getKeyword());
		
		return "redirect:/readView";
		
	}
	
	/** 댓글 수정 GET */
	@RequestMapping("/replyUpdateView")
	public String replyUpdateView(Reply dto, SearchCriteria scri, Model model) {
		
		model.addAttribute("replyUpdate", replyService.selectReply(dto.getRno()));
		model.addAttribute("scri", scri);
		
		return "board/replyUpdateView";
	}
	
	/** 댓글 수정 POST */
	@RequestMapping("/replyUpdate")
	public String replyUpdate(Reply dto, SearchCriteria scri, RedirectAttributes rttr) {
		
		replyService.updateReply(dto);
		
		rttr.addAttribute("bno", dto.getBno());
		rttr.addAttribute("page", scri.getPage());
		rttr.addAttribute("perPageNum", scri.getPerPageNum());
		rttr.addAttribute("searchType", scri.getSearchType());
		rttr.addAttribute("keyword", scri.getKeyword());
		
		return "redirect:/readView";
	}
	
	/** 댓글 삭제 GET */
	@RequestMapping("/replyDeleteView")
	public String replyDeleteView(Reply dto, SearchCriteria scri, Model model) {
		
		model.addAttribute("replyDelete", replyService.selectReply(dto.getRno()));
		model.addAttribute("scri", scri);
		

		return "board/replyDeleteView";
	}
	
	/** 댓글 삭제 */
	@RequestMapping("/replyDelete")
	public String replyDelete(Reply dto, SearchCriteria scri, RedirectAttributes rttr) {
		
		replyService.deleteReply(dto);
		
		rttr.addAttribute("bno", dto.getBno());
		rttr.addAttribute("page", scri.getPage());
		rttr.addAttribute("perPageNum", scri.getPerPageNum());
		rttr.addAttribute("searchType", scri.getSearchType());
		rttr.addAttribute("keyword", scri.getKeyword());
		
		return "redirect:/readView";
	}
	
}
