package com.work.intercepter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.work.dto.User;

import lombok.extern.slf4j.Slf4j;

@Component("BeforeActionIntercpter")
@Slf4j
public class BeforeActionIntercpter implements HandlerInterceptor {
	
	public boolean preHandle(Model model, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		
		User dto = (User)session.getAttribute("dto");
		
		boolean isLogin = false;
		boolean isAdmin = false;
		
		if(dto != null && dto.getUserId() != null) {
			isLogin = true;
		}
		
		if(dto != null && dto.getLoginType() == "A") {
			isAdmin = true;
		}
		
		request.setAttribute(null, dto);
		return false;
		
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
	}
		
	
}
