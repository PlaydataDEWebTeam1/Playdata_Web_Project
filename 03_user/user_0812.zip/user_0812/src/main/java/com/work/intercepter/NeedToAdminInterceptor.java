package com.work.intercepter;

import org.springframework.web.servlet.HandlerInterceptor;

public class NeedToAdminInterceptor implements HandlerInterceptor {

}
