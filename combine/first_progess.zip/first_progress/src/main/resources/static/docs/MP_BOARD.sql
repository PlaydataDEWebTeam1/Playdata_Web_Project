CREATE TABLE MP_BOARD(
    BNO NUMBER NOT NULL,
    TITLE VARCHAR2(100)     NOT NULL,
    CONTENT VARCHAR2(2000)  NOT NULL,
    WRITER VARCHAR2(100)    NOT NULL,
    REGDATE DATE            DEFAULT SYSDATE,
    PRIMARY KEY(BNO)
);

CREATE SEQUENCE MP_BOARD_SEQ
START WITH 1
INCREMENT BY 1;







INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '계란말이', '1.계란 5개를 실끈 제거 후 잘 풀어줍니다.', '김기영');
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '들깨곤약냉채', '1.닭가슴살은 끓는 물에 7분간 삶아 건진 뒤 결대로 찢는다.', '이희원');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '홍합배춧국', '1.배추와 무는 먹기 좋은 크기로 썰고 파와 홍고추는 어슷썬다.', '이택근');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '가지탕수육', '1.돼지고기는 소금, 후춧가루로 밑간한다.', '이태규');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '돈불고기 파인애플볶음', '1.돼지고기는 핏물을 제거하고, 양배추, 양파, 당근, 대파는 먹기 좋은 크기로 썬다.', '문수인');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '얼큰콩나물수제비', '1.밀가루에 소금을 섞어 물과 함께 반죽한 뒤 숙성시킨다.', '김기영');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '토마토 비빔국수', '1.삶은 달걀은 반으로 자르고, 양파는 채 썰어 찬물에 15분간 담가 매운 맛을 제거한 뒤에 채에 밭쳐 물기를 빼놓는다.', '김기영');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '알록달록 연근튀김', '1.연근은 얇게 썰어 찬물에 담가 전분기를 제거한다.', '김기영');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '바지락매생이전', '1.매생이와 바지락살은 소금기를 없애기 위해 물에 여러 번 행군다.', '문수인');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '과일깍두기', '1.배와 참외는 먹기 좋은 크기로 깍둑 썬다.', '이택근');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '통도라지 양념구이', '1.통도라지는 껍질을 제거하고 30분간 소금물에 담궈 쓴맛을 제거한다.', '이태규');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '청경채김치', '1.청경채는 줄기 부분에 칼집을 넣고, 소금을 뿌려 30분간 절인 후 씻어낸다.', '이희원');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '낙지 묵은지 콩나물국', '1.쌀뜨물과 국멸치로 육수를 우리고 멸치는 건져낸다.', '이택근');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '된장 숙성 저수분 수육', '1.돈육 앞다리살에 칼집을 낸다. 된장, 생강가루, 다진마늘, 통후추, 월계수잎을 섞어 놓는다.', '문수인');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '바지락 맑은국', '1.바지락은 이물질이 없도록 씻어 소금물에 해감한다.', '이태규');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '포항초 사과 샐러드', '1.포항초는 세척하고 먹기 좋은 크기로 썰고, 양파, 파프리카는 잘게 다진다.', '이희원');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '잣셰이크', '1.잣(20알)을 중간 불로 달궈진 마른 팬에 3분간 구워 식힌다.', '김기영');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '귤 채소 말이', '1.귤은 껍질을 까서 낱알로 떼어두고 파프리카, 적양배추는 채 썰고, 청상추는 라이스페이퍼 절반 크기로 뗴어둔다.', '김기영');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '도토리묵볶이', '1.건도토리묵은 물에 불린 뒤 끓는 물에서 데쳐 건진다.', '김기영');
     
INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '알밤 채소 간장조림', '1.밤, 당근, 표고버섯은 한입 크기로 썬다.', '김기영');

INSERT INTO MP_BOARD(BNO, TITLE, CONTENT, WRITER)
     VALUES (MP_BOARD_SEQ.NEXTVAL, '단호박찹쌀전', '1.단호박은 반으로 갈라 씨를 제거하고 작게 깍둑 썬 뒤, 전자레인지 용기에 담고 랩 또는 비닐을 덮어 전자레인지에 5분간 익힌 뒤 껍질을 벗겨 으깬다.', '김기영');     
     
SELECT * FROM MP_BOARD;
COMMIT;