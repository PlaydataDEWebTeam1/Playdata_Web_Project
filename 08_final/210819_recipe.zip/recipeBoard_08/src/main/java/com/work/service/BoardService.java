package com.work.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.work.dao.BoardDao;
import com.work.dto.Board;
import com.work.dto.Criteria;
import com.work.dto.SearchCriteria;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BoardService {
	@Autowired
	private BoardDao boardDao;


	
	/** 게시글 등록 */
	public int insert(Board dto) {
		int result = boardDao.insert(dto);		
		return result;
	}

	/** 게시글 목록 조회 */

	public List<Board> list(SearchCriteria cri) {
		return boardDao.list(cri);
	}
	
	/** 게시글 총 갯수 */
	public int listCount(SearchCriteria cri) {
		return boardDao.listCount(cri);
	}
	
	/** 게시글 조회 */
	public Board read(int bno) {
		return boardDao.read(bno);
	}
	
	/** 게시글 수정 */
	public int update(Board dto) {
		return boardDao.update(dto);
	}
	
	/** 게시글 삭제 */
	public int delete(int bno) {
		return boardDao.delete(bno);
	}
}



