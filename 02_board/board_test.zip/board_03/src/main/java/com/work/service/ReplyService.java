package com.work.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.work.dao.ReplyDao;
import com.work.dto.Reply;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ReplyService {
	@Autowired
	private ReplyDao replyDao;
	
	public List<Reply> readReply(int bno) {
		return replyDao.readReply(bno);
	}
	
	public int writeReply(Reply dto) {
		
		
		return replyDao.writeReply(dto);
	}
}
