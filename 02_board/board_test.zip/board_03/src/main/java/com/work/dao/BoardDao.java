package com.work.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import com.work.dto.Board;
import com.work.dto.Criteria;
import com.work.dto.SearchCriteria;

@Mapper
public interface BoardDao {

	// 게시글 작성 
	public int insert(Board dto);
	
	// 게시글 목록 조회
	public List<Board> list(SearchCriteria cri);
	
	// 게시글 총 갯수
	public int listCount(SearchCriteria cri);
	
	// 게시글 조회
	public Board read(int bno);
	
	// 게시글 수정 
	public void update(Board dto);
	
	// 게시글 삭제 
	public void delete(int dto);

}
	

