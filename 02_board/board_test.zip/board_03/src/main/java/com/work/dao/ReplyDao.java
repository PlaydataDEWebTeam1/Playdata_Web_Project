package com.work.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.work.dto.Reply;

@Mapper
public interface ReplyDao {
	
	// 댓글 조회
	public List<Reply> readReply(int bno);
	
	// 댓글 작성
	public int writeReply(Reply dto);
}
