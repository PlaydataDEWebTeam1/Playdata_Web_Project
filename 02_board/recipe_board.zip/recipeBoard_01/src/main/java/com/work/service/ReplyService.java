package com.work.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.work.dao.ReplyDao;
import com.work.dto.Reply;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ReplyService {
	@Autowired
	private ReplyDao replyDao;
	
	// 댓글 조회
	public List<Reply> readReply(int bno) {
		return replyDao.readReply(bno);
	}
	
	// 댓글 작성
	public int writeReply(Reply dto) {
		return replyDao.writeReply(dto);
	}
	
	// 댓글 수정 
	public int updateReply(Reply dto) {
		return replyDao.updateReply(dto);
	}
	// 댓글 삭제 
	public int deleteReply(Reply dto) {
		return replyDao.deleteReply(dto);
	}
	// 선택된 댓글 조회
	public Reply selectReply(int rno) {
		return replyDao.selectReply(rno);
	}
}
