create table mp_reply (
    bno number not null,
    rno number not null,
    content varchar2(1000) not null,
    writer varchar2(50) not null,
    regdate date default sysdate,
    primary key(bno, rno)
);

alter table mp_reply add constraint mp_reply_bno foreign key(bno)
references mp_board(bno);

create sequence mp_reply_seq START WITH 1 MINVALUE 0;






insert into mp_reply(bno, rno, content, writer)
    values(10, mp_reply_seq.nextval, '정말 유익한 레시피네요', '김기영');



select rno, content, writer, regdate
  from mp_reply
 where bno = 10;
 
commit;